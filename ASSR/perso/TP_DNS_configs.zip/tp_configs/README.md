# Fichiers de configuration — TP DNS Cache Poisoning / TSIG / DNSSEC

Cette archive regroupe l'ensemble des fichiers manipulés dans le TP.
Certains éléments (clé TSIG, clés DNSSEC, zone signée) sont **générés
dynamiquement** par les outils BIND9 : ils ne peuvent pas être livrés
"en dur" dans l'archive. Les fichiers correspondants sont fournis en
**modèles/placeholders**, avec les commandes exactes à exécuter pour
les produire vous-même.

## Arborescence

```text
.
├── scripts/
│   ├── build_architecture.sh     # construit namespaces + OVS + veth
│   └── clean_architecture.sh     # analyse build_architecture.sh et nettoie
│
├── partie1_attaque/               # état VULNERABLE (point de départ)
│   ├── bind-auth/
│   │   ├── named.conf
│   │   └── db.labo.tp
│   ├── bind-resolver/
│   │   └── named.conf
│   └── attacker/
│       └── attacker_spoof.py
│
├── partie2_tsig/                  # contre-mesure TSIG
│   ├── tsig.key.example           # MODELE, à régénérer (cf. ci-dessous)
│   ├── bind-auth/
│   │   ├── named.conf
│   │   └── db.labo.tp
│   └── bind-resolver/
│       └── named.conf
│
└── partie3_dnssec/                # contre-mesure DNSSEC
    ├── bind-auth/
    │   ├── named.conf
    │   └── db.labo.tp             # zone non signée, prête pour signature
    └── bind-resolver/
        └── named.conf             # ancre de confiance à compléter
```

## 1. Déploiement de la topologie

```bash
cd scripts/
chmod +x build_architecture.sh clean_architecture.sh
./build_architecture.sh
# ... travail dans le labo ...
./clean_architecture.sh
```

Les deux scripts sont indépendants du BUILD au sens où
`clean_architecture.sh` lit `build_architecture.sh` (présent dans le
même dossier) pour en extraire dynamiquement les noms de namespaces,
switches et interfaces : ne déplacez pas l'un sans l'autre.

## 2. Partie 1 — Copier les configs sur chaque namespace

```bash
# Sur auth
ip netns exec auth mkdir -p /etc/bind-auth /var/cache/bind-auth
cp partie1_attaque/bind-auth/* /etc/bind-auth/
ip netns exec auth named -c /etc/bind-auth/named.conf -u bind -g &

# Sur resolver
ip netns exec resolver mkdir -p /etc/bind-resolver /var/cache/bind-resolver
cp partie1_attaque/bind-resolver/named.conf /etc/bind-resolver/
ip netns exec resolver named -c /etc/bind-resolver/named.conf -u bind -g &

# Test
ip netns exec h1 dig www.labo.tp @10.0.2.10 +short     # -> 203.0.113.10

# Attaque
ip netns exec resolver rndc -s 10.0.2.10 flush
ip netns exec auth iptables -I OUTPUT -p udp --sport 53 -j DROP
ip netns exec attacker python3 partie1_attaque/attacker/attacker_spoof.py &
ip netns exec h1 dig www.labo.tp @10.0.2.10 +noall +answer
# -> 203.0.113.66 (cache empoisonné)
```

## 3. Partie 2 — Générer la clé TSIG puis déployer

La clé partagée **doit** être générée (son secret est aléatoire à
chaque génération) ; `tsig.key.example` n'est qu'un exemple de format.

```bash
ip netns exec auth tsig-keygen -a hmac-sha256 resolver-auth-key \
    > partie2_tsig/bind-auth/tsig.key

# Le même fichier, à l'identique, doit être présent côté resolver :
cp partie2_tsig/bind-auth/tsig.key partie2_tsig/bind-resolver/tsig.key

# Copie vers les namespaces puis (re)démarrage
cp partie2_tsig/bind-auth/*     /etc/bind-auth/
cp partie2_tsig/bind-resolver/* /etc/bind-resolver/
ip netns exec auth     rndc -s 10.0.3.10 reconfig
ip netns exec resolver rndc -s 10.0.2.10 reconfig

# Test : requête non signée directement sur auth -> REFUSED
ip netns exec h1 dig www.labo.tp @10.0.3.10 +norecurse
```

## 4. Partie 3 — Générer les clés DNSSEC, signer, puis déployer

```bash
cd /etc/bind-auth   # ou partie3_dnssec/bind-auth/ avant copie

# ZSK
ip netns exec auth dnssec-keygen -a RSASHA256 -b 2048 -n ZONE labo.tp
# KSK
ip netns exec auth dnssec-keygen -a RSASHA256 -b 2048 -f KSK -n ZONE labo.tp

ls Klabo.tp.*
# -> notez les identifiants xxxxx (ZSK) et yyyyy (KSK) générés

# Décommentez et complétez les deux lignes $INCLUDE dans db.labo.tp
# avec ces identifiants, puis signez la zone :
ip netns exec auth dnssec-signzone -o labo.tp \
    -k Klabo.tp.+008+yyyyy.key \
    db.labo.tp \
    Klabo.tp.+008+xxxxx.key
# -> produit db.labo.tp.signed

# Récupérez la clé KSK publique pour l'ancre de confiance du resolver :
cat Klabo.tp.+008+yyyyy.key
# Collez la chaîne base64 dans bind-resolver/named.conf (trust-anchors)

ip netns exec auth     rndc -s 10.0.3.10 reconfig
ip netns exec resolver rndc -s 10.0.2.10 reconfig

# Test de validation
ip netns exec resolver rndc -s 10.0.2.10 flush
ip netns exec h1 dig www.labo.tp @10.0.2.10 +dnssec +multi
# -> présence du flag "ad" (Authenticated Data)
```

## Nettoyage complet

```bash
for ns in auth resolver; do
    ip netns exec "${ns}" pkill -f named || true
done
./scripts/clean_architecture.sh
rm -rf /etc/bind-auth /etc/bind-resolver
```

---

**Rappel de sécurité :** ces configurations et ce script d'attaque ne
doivent être utilisés que dans le laboratoire isolé décrit dans le
support de TP (namespaces + OVS, sans accès réseau externe). Ne les
exécutez jamais contre des systèmes ou réseaux qui ne vous appartiennent
pas.
