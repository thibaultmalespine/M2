#!/usr/bin/env bash
#
# clean_architecture.sh
# Supprime la topologie en analysant build_architecture.sh
#
set -uo pipefail   # pas de -e : le nettoyage doit continuer même si une
                    # ressource n'existe pas (idempotence)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_SCRIPT="${SCRIPT_DIR}/build_architecture.sh"

log()  { echo -e "[*] $*"; }
warn() { echo -e "[!] $*" >&2; }

if [[ ! -f "${BUILD_SCRIPT}" ]]; then
    warn "build_architecture.sh introuvable dans ${SCRIPT_DIR}."
    warn "Nettoyage annulé : impossible d'analyser la topologie."
    exit 1
fi

# --- 1. Extraction des namespaces (tableaux NAMESPACES_*) -----------------
mapfile -t NAMESPACES < <(
    grep -oP '^NAMESPACES_\w+=\(\K[^)]*' "${BUILD_SCRIPT}" \
      | tr -s ' \t' '\n' \
      | sed '/^$/d'
)

# --- 2. Extraction des switches OVS (tableau SWITCHES) ---------------------
mapfile -t SWITCHES < <(
    grep -oP '^SWITCHES=\(\K[^)]*' "${BUILD_SCRIPT}" \
      | tr -s ' \t' '\n' \
      | sed '/^$/d'
)

# --- 3. Extraction des ports veth côté switch (appels attach_veth) --------
# Signature : attach_veth <namespace> <ifname_ns> <bridge> <brport>
mapfile -t BRPORTS < <(
    grep -oP '^\s*attach_veth\s+\S+\s+\S+\s+\S+\s+\K\S+' "${BUILD_SCRIPT}" \
      | sed '/^$/d'
)

# Les interfaces veth côté namespace sont, elles, détruites
# automatiquement dès que le namespace correspondant est supprimé (un
# veth est une paire indissociable : supprimer une extrémité détruit
# l'autre). On les liste malgré tout, à titre informatif / défensif.
mapfile -t NSPORTS < <(
    grep -oP '^\s*attach_veth\s+\S+\s+\K\S+' "${BUILD_SCRIPT}" \
      | sed '/^$/d'
)

log "Namespaces détectés : ${NAMESPACES[*]:-aucun}"
log "Switches détectés   : ${SWITCHES[*]:-aucun}"
log "Ports OVS détectés  : ${BRPORTS[*]:-aucun}"

# --- 4. Suppression des namespaces (entraîne la suppression des veth) ----
for ns in "${NAMESPACES[@]:-}"; do
    [[ -z "${ns}" ]] && continue
    if ip netns list | grep -qw "${ns}"; then
        ip netns del "${ns}" && log "Namespace supprimé : ${ns}"
    fi
done

# --- 5. Suppression des switches OVS --------------------------------------
for br in "${SWITCHES[@]:-}"; do
    [[ -z "${br}" ]] && continue
    if ovs-vsctl br-exists "${br}" 2>/dev/null; then
        ovs-vsctl del-br "${br}" && log "Switch OVS supprimé : ${br}"
    fi
done

# --- 6. Nettoyage défensif des veth résiduels dans le namespace racine ---
for ifname in "${BRPORTS[@]:-}" "${NSPORTS[@]:-}"; do
    [[ -z "${ifname}" ]] && continue
    if ip link show "${ifname}" &>/dev/null; then
        ip link del "${ifname}" && log "Interface résiduelle supprimée : ${ifname}"
    fi
done

log "=== Nettoyage terminé ==="
