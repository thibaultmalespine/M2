#!/usr/bin/env bash
#
# build_architecture.sh
# Construit le laboratoire DNS Cache Poisoning / TSIG / DNSSEC
# Namespaces + Open vSwitch + veth
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLEAN_SCRIPT="${SCRIPT_DIR}/clean_architecture.sh"

# --- 0. Nettoyage préalable (idempotence) ---------------------------------
if [[ -x "${CLEAN_SCRIPT}" ]]; then
    echo "[*] Nettoyage de l'état précédent..."
    "${CLEAN_SCRIPT}" || true
fi

# --- 1. Paramètres de topologie --------------------------------------------
NAMESPACES_HOSTS=(h1 resolver auth attacker)
NAMESPACES_ROUTERS=(r1)
SWITCHES=(sw1 sw2 sw3)

# --- 2. Fonctions utilitaires ------------------------------------------
log() { echo -e "[*] $*"; }

create_ns() {
    local ns="$1"
    ip netns add "${ns}"
    ip netns exec "${ns}" ip link set lo up
    log "Namespace créé : ${ns}"
}

create_switch() {
    local br="$1"
    ovs-vsctl --may-exist add-br "${br}"
    ip link set "${br}" up
    log "Switch OVS créé : ${br}"
}

# Crée une paire veth, place une extrémité dans un namespace (avec un nom
# interne), et attache l'autre extrémité à un bridge OVS.
# Usage : attach_veth <namespace> <nom_interface_dans_ns> <bridge> <port_sur_bridge>
attach_veth() {
    local ns="$1" ifname="$2" br="$3" brport="$4"

    ip link add "${ifname}" type veth peer name "${brport}"
    ip link set "${ifname}" netns "${ns}"
    ip link set "${brport}" up
    ovs-vsctl --may-exist add-port "${br}" "${brport}"
    ip netns exec "${ns}" ip link set "${ifname}" up

    log "veth ${ifname} (ns=${ns}) <-> ${brport} (${br})"
}

set_ip() {
    local ns="$1" ifname="$2" cidr="$3"
    ip netns exec "${ns}" ip addr add "${cidr}" dev "${ifname}"
}

enable_forwarding() {
    local ns="$1"
    ip netns exec "${ns}" sysctl -w net.ipv4.ip_forward=1 >/dev/null
    log "IP forwarding activé dans ${ns}"
}

add_route() {
    local ns="$1" dest="$2" via="$3"
    ip netns exec "${ns}" ip route add "${dest}" via "${via}"
}

# --- 3. Création des namespaces ------------------------------------------
log "=== Création des namespaces hôtes ==="
for ns in "${NAMESPACES_HOSTS[@]}"; do
    create_ns "${ns}"
done

log "=== Création des namespaces routeurs ==="
for ns in "${NAMESPACES_ROUTERS[@]}"; do
    create_ns "${ns}"
done

# --- 4. Création des switches OVS -----------------------------------------
log "=== Création des switches OVS ==="
for br in "${SWITCHES[@]}"; do
    create_switch "${br}"
done

# --- 5. Câblage (veth) + rattachement aux switches -------------------------
log "=== Câblage des interfaces ==="

# Segment N1 : h1 <-> sw1 <-> r1
attach_veth h1 veth-h1   sw1 veth-h1-br
attach_veth r1 veth-r1a  sw1 veth-r1a-br

# Segment N2 : r1 <-> sw2 <-> resolver
attach_veth r1       veth-r1b    sw2 veth-r1b-br
attach_veth resolver veth-res-a  sw2 veth-res-a-br

# Segment N3 : resolver <-> sw3 <-> auth / attacker
attach_veth resolver veth-res-b sw3 veth-res-b-br
attach_veth auth     veth-auth sw3 veth-auth-br
attach_veth attacker veth-att  sw3 veth-att-br

# --- 6. Adressage IP ---------------------------------------------------
log "=== Adressage IP ==="
set_ip h1       veth-h1    10.0.1.10/24
set_ip r1       veth-r1a   10.0.1.1/24
set_ip r1       veth-r1b   10.0.2.1/24
set_ip resolver veth-res-a 10.0.2.10/24
set_ip resolver veth-res-b 10.0.3.1/24
set_ip auth     veth-auth  10.0.3.10/24
set_ip attacker veth-att   10.0.3.66/24

# --- 7. IP forwarding (routeur + résolveur multi-interfaces) ------------
log "=== Activation de l'IP forwarding ==="
enable_forwarding r1
enable_forwarding resolver

# --- 8. Routage statique --------------------------------------------------
log "=== Routage statique ==="
# h1 : tout passe par r1
add_route h1 default 10.0.1.1

# r1 : connaît directement N1 et N2 ; doit apprendre N3 via resolver
add_route r1 10.0.3.0/24 10.0.2.10

# resolver : connaît directement N2 et N3 ; doit apprendre N1 via r1
add_route resolver 10.0.1.0/24 10.0.2.1

# auth et attacker n'ont besoin d'aucune route supplémentaire : leurs
# seuls correspondants (resolver, puis h1 par rebond) sont sur N3.

# --- 9. Mode "hub" sur sw3 pour l'observation pédagogique de l'attaquant --
log "=== Passage de sw3 en mode hub (flood) pour la démonstration ==="
ovs-ofctl del-flows sw3
ovs-ofctl add-flow sw3 "actions=flood"

log "=== Architecture construite avec succès ==="
echo
echo "Résumé rapide :"
ip netns list
echo
ovs-vsctl show
